package com.example.festafimdeano.constant;

public class FimDeAnoConstants {

    public static String PRESENCE_KEY = "presenceKey";
    public static String CONFIRMATION_YES = "CONFIRMATION_YES";
    public static String CONFIRMATION_NO = "CONFIRMATION_NO";


}
