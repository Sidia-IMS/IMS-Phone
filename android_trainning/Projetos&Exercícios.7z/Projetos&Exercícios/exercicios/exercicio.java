public class exercicio {

    private String helloWorld(String str) {
        return "A palavra possui " + str.length() + " caracteres.";

    }

    public static void main(String[] args) {
        exercicio funcoes = new exercicio();

        System.out.println(funcoes.helloWorld("teste"));
           }

}
