import java.util.Scanner;

public class InformacoesDeUsuario {
    public static void main(String[] args) {
        Integer valor;
        Scanner scanner= new Scanner(System.in);
        //System.out.print("Informe um nome: ");
        System.out.print("Informe um numero: ");
        valor = scanner.nextInt();
        //String str = scanner.nextLine();
        System.out.println(valor + 10);
       // System.out.println(str);
    }
}
