/*
 * Type Bit
 *    Double 64
 *    Float  32
 *    Long   64
 *    Int    32
 *    Short  16
 *    Byte    8
 *    Char    2
 *    String  ?
 *    Boolean ?
 * */


public class Variaveis {
    public static void main(String[] args) {

        Integer numero = 10;
/*
        System.out.println(numero + 90);
        System.out.println(numero - 80);
        System.out.println(numero * 2);
        System.out.println(numero / 3);
        System.out.println(numero % 3);
        */

       //  numero = numero * 2;
        numero++;
        System.out.println(numero);
    }


}
