public class OlaMundo {
    //Esse metodo é o ponto de entrada
    public static void main(String[] args) {
        System.out.println("Hello World");


    }


}
