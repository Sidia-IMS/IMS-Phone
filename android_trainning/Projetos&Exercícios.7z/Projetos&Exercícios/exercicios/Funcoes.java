public class Funcoes {

    private void helloWorld() {
        System.out.println("Ola, mundo");
    }

    private long soma(long a, long b){
        return a+b;
    }



    public static void main(String[] args) {
        //Funcoes abc =new Funcoes();
       //abc.helloWorld();

        String str = "Curso de Java";
        str.charAt(2);

        System.out.println(str.equals("uhtuhtht"));



    }



}
